@extends('layouts.master')
@section('content')
    <div class="row">
        <div class="col-md-12">
            <h4 class="card-title">Create New Donation</h4>
            <div class="card">
                <div class="card-content">
                    <form method="POST" action="{{route('donations.store')}}" class="form-horizontal">
                        @csrf
                        <div class="row">
                            <div class="col-md-12">
                                <p>Receiver Name</p>
                                <div class="form-group label-floating is-empty{{ $errors->has('receiver_name') ? ' has-error' : '' }}">
                                    <label class="control-label"></label>
                                    <input type="text" name="receiver_name" class="form-control date" value="{{ old('receiver_name') }}" required>
                                    <span class="help-block">An Donation Receiver.</span>
                                    @if ($errors->has('receiver_name'))
                                        <strong class="text-danger">{{ $errors->first('receiver_name') }}</strong>
                                    @endif
                                </div>
                            </div>
                            {{-- /col-md-6 --}}
                        </div>
                        <!-- /row -->
                        
                        <div class="row">

                        <div class="col-md-4">
                                <p>Pack</p>
                                <div class="form-group label-floating is-empty{{ $errors->has('pack') ? ' has-error' : '' }}">
                                    <label class="control-label"></label>
                                    <select name="hopsital" class="form-control">
                                        <option>DOUBLE</option>
                                        <option>SINGLE</option>
                                    </select>
                                    <span class="help-block">An Donation Pack .</span>
                                    @if ($errors->has('hospital'))
                                        <strong class="text-danger">{{ $errors->first('pack') }}</strong>
                                    @endif
                                </div>
                            </div>
                            {{-- /col-md-6 --}}

                            <div class="col-md-4">
                                <p>Start Time</p>
                                <div class="form-group label-floating is-empty{{ $errors->has('start_time') ? ' has-error' : '' }}">
                                    <label class="control-label"></label>
                                    <input type="time" name="start_time" class="form-control date" value="{{ old('start_time') }}" required>
                                    <span class="help-block">An Donation Receiver.</span>
                                    @if ($errors->has('start_time'))
                                        <strong class="text-danger">{{ $errors->first('start_time') }}</strong>
                                    @endif
                                </div>
                            </div>
                            {{-- /col-md-6 --}}


                            <div class="col-md-4">
                                <p>End  Time</p>
                                <div class="form-group label-floating is-empty{{ $errors->has('end_time') ? ' has-error' : '' }}">
                                    <label class="control-label"></label>
                                    <input type="time" name="end_time" class="form-control date" value="{{ old('end_time') }}" required>
                                    <span class="help-block">An Donation End Time.</span>
                                    @if ($errors->has('end_time'))
                                        <strong class="text-danger">{{ $errors->first('end_time') }}</strong>
                                    @endif
                                </div>
                            </div>
                            {{-- /col-md-6 --}}


                        </div>

                        <div class="row">

                            <div class="col-md-6">
                                <p>Hospital</p>
                                <div class="form-group label-floating is-empty{{ $errors->has('end_time') ? ' has-error' : '' }}">
                                    <label class="control-label"></label>
                                    <select name="hopsital" class="form-control">
                                        <option>EFSTH</option>
                                        <option>KANIFING HOSPITAL</option>
                                        <option>BANSANG HOSPITAL</option>
                                        <option>BWIAM HOSPITAL</option>
                                    </select>
                                    <span class="help-block">An Appointment Hospital.</span>
                                    @if ($errors->has('hospital'))
                                        <strong class="text-danger">{{ $errors->first('hospital') }}</strong>
                                    @endif
                                </div>
                            </div>
                            {{-- /col-md-6 --}}
                            <div class="col-md-6">
                                <p>Donor</p>
                                <div class="form-group label-floating is-empty{{ $errors->has('donor') ? ' has-error' : '' }}">
                                    <label class="control-label"></label>
                                    <select name="donor" class="form-control">
                                        <option>BSIS1900001</option>
                                        <option>BSIS1900001</option>
                                        <option>BSIS1900001</option>
                                    </select>
                                    <span class="help-block">An Appointment Donor.</span>
                                    @if ($errors->has('donor'))
                                        <strong class="text-danger">{{ $errors->first('donor') }}</strong>
                                    @endif
                                </div>
                            </div>
                            {{-- /col-md-6 --}}
                           
                            <h3 style="margin-top:10px; margin-right:30px;">Donor Assestment</h3>
                            <hr>
                            <div class="row">

                            <div class="col-md-4">
                                <p>Weight</p>
                                <div class="form-group label-floating is-empty{{ $errors->has('weigth') ? ' has-error' : '' }}">
                                    <label class="control-label"></label>
                                    <input type="text" name="weight" class="form-control date" value="{{ old('weight') }}" placeholder="kg" required>
                                    <span class="help-block">An Donation Weigth.</span>
                                    @if ($errors->has('end_time'))
                                        <strong class="text-danger">{{ $errors->first('weight') }}</strong>
                                    @endif
                                </div>
                            </div>
                            {{-- /col-md-6 --}}

                            <div class="col-md-4">
                                <p>Pulse</p>
                                <div class="form-group label-floating is-empty{{ $errors->has('pulse') ? ' has-error' : '' }}">
                                    <label class="control-label"></label>
                                    <input type="text" name="pulse" class="form-control" value="{{ old('pulse') }}" required>
                                    <span class="help-block">An Donation Pulse.</span>
                                    @if ($errors->has('pulse'))
                                        <strong class="text-danger">{{ $errors->first('pulse') }}</strong>
                                    @endif
                                </div>
                            </div>
                            {{-- /col-md-6 --}}


                            <div class="col-md-4">
                                <p>Adverse Event</p>
                                <div class="form-group label-floating is-empty{{ $errors->has('donor') ? ' has-error' : '' }}">
                                    <label class="control-label"></label>
                                    <select name="donor" class="form-control">
                                        <option>ACCIDENT</option>
                                        <option>ALLERGY</option>
                                        <option>CONVULSIONS</option>
                                        <option>HAEMATOMA</option>
                                        <option>HYPERVENTILATION</option>
                                        <option>NAUSEA</option>
                                        <option>NERVE INJURY</option>
                                        <option>OTHER</option>
                                    </select>
                                    <span class="help-block">An Appointment Donor.</span>
                                    @if ($errors->has('donor'))
                                        <strong class="text-danger">{{ $errors->first('donor') }}</strong>
                                    @endif
                                </div>
                            </div>
                            {{-- /col-md-6 --}}
                            
                            </div>


                        </div>

                        <button type="submit" class="btn btn-info pull-right">Save</button>
                        <a href="{{route('donations.index')}}" type="button" class="btn btn-danger pull-left">Close
                        </a>
                    </form>
                    <!-- /form -->
                </div>
                <!-- /card-content -->
            </div>
            <!-- /card -->
        </div>
        <!-- /col-md-12 -->
    </div>
    <!--  /row -->
@stop

@section('scripts')
    <script src="/assets/vendors/jquery-3.1.1.min.js" type="text/javascript"></script>
@stop    
   

