<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BloodTest extends Model
{
    //
}
