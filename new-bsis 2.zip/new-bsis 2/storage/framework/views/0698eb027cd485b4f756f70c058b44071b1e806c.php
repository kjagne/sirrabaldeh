<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <h4 class="card-title">Create New Blood Test</h4>
            <div class="card">
                <div class="card-content">
                    <form method="POST" action="<?php echo e(route('blood_test_results.store')); ?>" class="form-horizontal">
                        <?php echo csrf_field(); ?>
                        <div class="row">

                            <div class="col-md-12">
                                <p>Blood Test</p>
                                <div class="form-group label-floating is-empty<?php echo e($errors->has('blood_test') ? ' has-error' : ''); ?>">
                                    <label class="control-label"></label>
                                    <select name="blood_test" class="form-control">
                                        <option>TTIs</option>
                                        <option>TTIs</option>
                                        <option>TTIs</option>
                                        <option>TTIs</option>
                                    </select>
                                    <span class="help-block">An Blood Test Name.</span>
                                    <?php if($errors->has('blood_test')): ?>
                                        <strong class="text-danger"><?php echo e($errors->first('blood_test')); ?></strong>
                                    <?php endif; ?>
                                </div>
                            </div>
                            
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                                <p>Result Label</p>
                                <div class="form-group label-floating is-empty<?php echo e($errors->has('result_label') ? ' has-error' : ''); ?>">
                                    <label class="control-label"></label>
                                    <input type="text" class="form-control" >
                                    <span class="help-block">An Blood Test Result Label.</span>
                                    <?php if($errors->has('result_label')): ?>
                                        <strong class="text-danger"><?php echo e($errors->first('result_label')); ?></strong>
                                    <?php endif; ?>
                                </div>
                            </div>
                            


                        </div>
                        <!-- /row -->
                        
                        <div class="row">
                            <div class="col-md-12">
                                <p>Result Details</p>
                                <div class="form-group label-floating is-empty<?php echo e($errors->has('result_detail') ? ' has-error' : ''); ?>">
                                    <label class="control-label"></label>
                                    <textarea name="result_detail" class="form-control" cols="30" rows="10"></textarea>
                                    <span class="help-block">An Blood Test Result Details.</span>
                                    <?php if($errors->has('result_detail')): ?>
                                        <strong class="text-danger"><?php echo e($errors->first('result_detail')); ?></strong>
                                    <?php endif; ?>
                                </div>
                            </div>
                            


                        </div>
                        <!-- /row -->

                        <button type="submit" class="btn btn-info pull-right">Save</button>
                        <a href="<?php echo e(route('appointments.index')); ?>" type="button" class="btn btn-danger pull-left">Close
                        </a>
                    </form>
                    <!-- /form -->
                </div>
                <!-- /card-content -->
            </div>
            <!-- /card -->
        </div>
        <!-- /col-md-12 -->
    </div>
    <!--  /row -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>