<?php $__env->startSection('content'); ?>

    <div class="block-header">
        <?php if(session('status')): ?>
            <br>
            <?php $type = 'info'; ?>
            <?php if(session('status_type')): ?> <?php $type = session('status_type'); ?> <?php endif; ?>
            <div class="alert alert-<?php echo e($type); ?>">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>
                <?php echo session('status'); ?>

            </div>
        <?php endif; ?>
    </div>
    <!-- /block-header -->
    <div class="row">
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-6 pull-left">
                    <ol class="breadcrumb" style="background-color: transparent">
                        <li class="active"><a href="">Donations</a></li>
                    </ol>
                </div>
                <!-- /col-6 -->
                <div class="col-md-6">
                    <a href="<?php echo e(route('donations.create')); ?>" class="btn btn-primary pull-right">Add Donation</a>
                </div>
            </div>
            <!-- /row -->


            <div class="card">
                <div class="card-content">
                    <h4 class="card-title">Donations List</h4>
                    <div class="toolbar">

                    </div>
                    <!-- /toolbar -->
                    <div class="material-datatables">
                        <table class="table table-striped table-no-bordered table-hover datatables" cellspacing="0" width="100%" style="width:100%">
                            <thead>
                            <tr>
                                <th>Hospital</th>
                                <th>Donor</th>
                                <th>Receiver Name</th>
                                <th>Date</th>
                            </tr>
                            </thead>
                            <tbody>
                            <tr>
                                <td>EFSTH</td>
                                <td>BSIS1900001</td>
                                <td>FATOU CEESAY</td>
                                <td>2019-09-03</td>
                            </tr>
                            <tr>
                                <td>EFSTH</td>
                                <td>BSIS1900001</td>
                                <td>FATOU CEESAY</td>
                                <td>2019-09-03</td>
                            </tr>
                            <tr>
                                <td>EFSTH</td>
                                <td>BSIS1900001</td>
                                <td>FATOU CEESAY</td>
                                <td>2019-09-03</td>
                            </tr>
                            <tr>
                                <td>EFSTH</td>
                                <td>BSIS1900001</td>
                                <td>FATOU CEESAY</td>
                                <td>2019-09-03</td>
                            </tr>
                            </tbody>
                        </table>
                        <!-- /table -->
                    </div>
                    <!-- /materials-datables -->
                </div>
                <!-- /card-content -->
            </div>
            <!-- /card -->
        </div>
        <!-- /col-12 -->
    </div>
    <!-- /row -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="/assets/vendors/jquery-3.1.1.min.js" type="text/javascript"></script>
    <script type="text/javascript">
        $(document).ready(function () {
            $('.datatables').DataTable({
                "pagingType": "full_numbers",
                "lengthMenu": [
                    [10, 25, 50, -1],
                    [10, 25, 50, "All"]
                ],
                responsive: true,
                language: {
                    search: "_INPUT_",
                    searchPlaceholder: "Search records",
                }

            });

        });
    </script>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>