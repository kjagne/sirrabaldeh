<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <h4 class="card-title">Create New Donor Counselling</h4>
            <div class="card">
                <div class="card-content">
                    <form method="POST" action="<?php echo e(route('blood_tests.store')); ?>" class="form-horizontal">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-md-6">
                                <p>Counselling From</p>
                                <div class="form-group label-floating is-empty<?php echo e($errors->has('from') ? ' has-error' : ''); ?>">
                                    <label class="control-label"></label>
                                    <input type="date" name="from" class="form-control date" value="<?php echo e(old('from')); ?>" required>
                                    <span class="help-block">An Counselling From.</span>
                                    <?php if($errors->has('from')): ?>
                                        <strong class="text-danger"><?php echo e($errors->first('from')); ?></strong>
                                    <?php endif; ?>
                                </div>
                            </div>
                            

                            <div class="col-md-6">
                                <p>Counselling To</p>
                                <div class="form-group label-floating is-empty<?php echo e($errors->has('from') ? ' has-error' : ''); ?>">
                                    <label class="control-label"></label>
                                    <input type="date" name="to" class="form-control date" value="<?php echo e(old('to')); ?>" required>
                                    <span class="help-block">An Counselling To.</span>
                                    <?php if($errors->has('to')): ?>
                                        <strong class="text-danger"><?php echo e($errors->first('to')); ?></strong>
                                    <?php endif; ?>
                                </div>
                            </div>
                            


                        </div>
                        <div class="row">

                            <div class="col-md-4">
                                <p>Hospital</p>
                                <div class="form-group label-floating is-empty<?php echo e($errors->has('end_time') ? ' has-error' : ''); ?>">
                                    <label class="control-label"></label>
                                    <select name="hopsital" class="form-control">
                                        <option>EFSTH</option>
                                        <option>KANIFING HOSPITAL</option>
                                        <option>BANSANG HOSPITAL</option>
                                        <option>BWIAM HOSPITAL</option>
                                    </select>
                                    <span class="help-block">An Counselling Hospital.</span>
                                    <?php if($errors->has('hospital')): ?>
                                        <strong class="text-danger"><?php echo e($errors->first('hospital')); ?></strong>
                                    <?php endif; ?>
                                </div>
                            </div>
                            
                            <div class="col-md-4">
                                <p>Donor</p>
                                <div class="form-group label-floating is-empty<?php echo e($errors->has('donor') ? ' has-error' : ''); ?>">
                                    <label class="control-label"></label>
                                    <select name="donor" class="form-control">
                                        <option>BSIS1900001</option>
                                        <option>BSIS1900001</option>
                                        <option>BSIS1900001</option>
                                    </select>
                                    <span class="help-block">An Appointment Donor.</span>
                                    <?php if($errors->has('donor')): ?>
                                        <strong class="text-danger"><?php echo e($errors->first('donor')); ?></strong>
                                    <?php endif; ?>
                                </div>
                            </div>
                            

                            <div class="col-md-4">
                                <p>Status</p>
                                <div class="form-group label-floating is-empty<?php echo e($errors->has('status') ? ' has-error' : ''); ?>">
                                    <label class="control-label"></label>
                                    <select name="status" class="form-control">
                                        <option>RECEIVED COUNSELLING</option>
                                        <option>REFUSED COUNSELLING</option>
                                        <option>DO NOT RECEIVE COUNSELLING</option>
                                    </select>
                                    <span class="help-block">A Counselling Status.</span>
                                    <?php if($errors->has('status')): ?>
                                        <strong class="text-danger"><?php echo e($errors->first('status')); ?></strong>
                                    <?php endif; ?>
                                </div>
                            </div>
                            
                        </div>

                        <div class="row">

                        <div class="col-md-12">
                                <p>Counselling Notes</p>
                                <div class="form-group label-floating is-empty<?php echo e($errors->has('notes') ? ' has-error' : ''); ?>">
                                    <label class="control-label"></label>
                                    <textarea name="text" class="form-control" cols="30" rows="10"></textarea>
                                    <span class="help-block">An Counselling Notes.</span>
                                    <?php if($errors->has('notes')): ?>
                                        <strong class="text-danger"><?php echo e($errors->first('notes')); ?></strong>
                                    <?php endif; ?>
                                </div>
                            </div>
                            
                        
                        </div>

                        <button type="submit" class="btn btn-info pull-right">Save</button>
                        <a href="<?php echo e(route('donors.index')); ?>" type="button" class="btn btn-danger pull-left">Close
                        </a>
                    </form>
                    <!-- /form -->
                </div>
                <!-- /card-content -->
            </div>
            <!-- /card -->
        </div>
        <!-- /col-md-12 -->
    </div>
    <!--  /row -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>