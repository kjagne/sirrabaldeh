<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <h4 class="card-title">Create New Hospital</h4>
            <div class="card">
                <div class="card-content">
                    <form method="POST" action="<?php echo e(route('hospitals.store')); ?>" class="form-horizontal">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-md-4">
                                <p>Hospital Name</p>
                                <div class="form-group label-floating is-empty<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                                    <label class="control-label"></label>
                                    <input type="text" name="name" class="form-control" value="<?php echo e(old('name')); ?>" required>
                                    <span class="help-block">A Hospital Name.</span>
                                    <?php if($errors->has('name')): ?>
                                        <strong class="text-danger"><?php echo e($errors->first('name')); ?></strong>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="col-md-4">
                                <p>Hospital Location</p>
                                <div class="form-group label-floating is-empty<?php echo e($errors->has('location') ? ' has-error' : ''); ?>">
                                    <label class="control-label"></label>
                                    <input type="text" name="location" class="form-control" value="<?php echo e(old('location')); ?>" required>
                                    <span class="help-block">A Hospital Name.</span>
                                    <?php if($errors->has('location')): ?>
                                        <strong class="text-danger"><?php echo e($errors->first('location')); ?></strong>
                                    <?php endif; ?>
                                </div>
                            </div>
                            


                            <div class="col-md-4">
                                <p>Hospital Email</p>
                                <div class="form-group label-floating is-empty<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                                    <label class="control-label"></label>
                                    <input type="email" name="email" class="form-control" value="<?php echo e(old('email')); ?>" required>
                                    <span class="help-block">A Hospital Email.</span>
                                    <?php if($errors->has('email')): ?>
                                        <strong class="text-danger"><?php echo e($errors->first('email')); ?></strong>
                                    <?php endif; ?>
                                </div>
                            </div>
                            

                        </div>
                        <!-- /row -->

                        <div class="row">



                            <div class="col-md-4">
                                <p>Username</p>
                                <div class="form-group label-floating is-empty<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                                    <label class="control-label"></label>
                                    <input type="email" name="email" class="form-control" value="<?php echo e(old('email')); ?>" required>
                                    <span class="help-block">A Hospital username.</span>
                                    <?php if($errors->has('email')): ?>
                                        <strong class="text-danger"><?php echo e($errors->first('email')); ?></strong>
                                    <?php endif; ?>
                                </div>
                            </div>
                            
                            <div class="col-md-4">
                                <p>Password</p>
                                <div class="form-group label-floating is-empty<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                                    <label class="control-label"></label>
                                    <input type="password" name="password" class="form-control" value="<?php echo e(old('password')); ?>" required>
                                    <span class="help-block">A Hospital password.</span>
                                    <?php if($errors->has('password')): ?>
                                        <strong class="text-danger"><?php echo e($errors->first('password')); ?></strong>
                                    <?php endif; ?>
                                </div>
                            </div>
                            
                            <div class="col-md-4">
                                <p>Confirm Password</p>
                                <div class="form-group label-floating is-empty<?php echo e($errors->has('password_confirmation') ? ' has-error' : ''); ?>">
                                    <label class="control-label"></label>
                                    <input type="password" name="password_confirmation" class="form-control" value="<?php echo e(old('password_confirmation')); ?>" required>
                                    <span class="help-block">A Hospital password.</span>
                                    <?php if($errors->has('password_confirmation')): ?>
                                        <strong class="text-danger"><?php echo e($errors->first('password_confirmation')); ?></strong>
                                    <?php endif; ?>
                                </div>
                            </div>
                            

                        </div>

                        <button type="submit" class="btn btn-info pull-right">Save</button>
                        <a href="<?php echo e(route('hospitals.index')); ?>" type="button" class="btn btn-danger pull-left">Close
                        </a>
                    </form>
                    <!-- /form -->
                </div>
                <!-- /card-content -->
            </div>
            <!-- /card -->
        </div>
        <!-- /col-md-12 -->
    </div>
    <!--  /row -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="/assets/vendors/jquery-3.1.1.min.js" type="text/javascript"></script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>